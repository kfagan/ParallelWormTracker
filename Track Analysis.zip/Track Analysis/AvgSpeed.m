

function [linear, angular] = AvgSpeed(Track,samplerate)
    %%%% average linear and angular speeds over 10s intervals
        linear = [];
        angular = [];
        frame = [];
        tenseconds = 10*samplerate;
        for t = 0:tenseconds:length(Track.Path)-tenseconds
            linear = [linear round(mean(Track.Speed(1+t:tenseconds+t))*1000)/1000];
            angular = [angular round(mean(abs(Track.AngSpeed(1+t:tenseconds+t))))];
            frame = [frame round(mean(Track.Frames(1+t:tenseconds+t)))];
        end
end
