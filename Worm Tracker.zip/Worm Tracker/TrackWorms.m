     function TrackWorms(image_name,start,numFrames,bg)

% 2015-05-04    Updated to accept movie formats beyond .avi, using
% VideoReader (introduced in R2010b)
% Author: Jan Kubanek (kubanek@go.wustl.edu)

recordbw = 0; %whether to record the video as bw instead of gray

WormTrackerPrefs.MinWormArea = 200;
WormTrackerPrefs.MaxWormArea = 2000;
WormTrackerPrefs.MaxDistance = 50;
WormTrackerPrefs.SizeChangeThreshold = 500; %usually 200
WormTrackerPrefs.MinTrackLength = 200;
WormTrackerPrefs.AutoThreshold = 0;
WormTrackerPrefs.ManualSetLevel = 0.5; %im2bw() contrast
WormTrackerPrefs.DarkObjects = 0;
WormTrackerPrefs.PlotRGB = 0;
WormTrackerPrefs.PauseDuringPlot = 0;
WormTrackerPrefs.PlotObjectSizeHistogram = 0;
% WormTrackerPrefs.CorrectFactor = 0.3;
WormTrackerPrefs.CorrectFactor = 0.09;
%image resolution
RES_H = 3840;
RES_V = 2748;
framerate = 1; %fps
NumberOfFrames = numFrames; %total number of video frames

bgName = strcat(image_name,'_',sprintf('%04d.bmp',bg));
bgImage = 255 - imread(bgName);
background = imopen(bgImage,strel('disk',5));


%---------------------
%clipping

%clip to a rectangle; no clip if empty
 rectangularclip = [];
rectangularclip = [300,2700,600,3400];

%clip to a circle; no clip if empty

%focus 2015-10-05 nobact
%focuspar = [310, 130, 6];

%2015-10-12
% focuspar = [220, -40, 7];
% center_x = RES_H / 2 - focuspar(1);
% center_y = RES_V / 2 - focuspar(2);
% radius = RES_V / focuspar(3);
% circularclip = [center_x, center_y, radius]; %center_x, center_y, radius
 circularclip = []; 


% Setup figure for plotting tracker results
% -----------------------------------------
WTFigH = findobj('Tag', 'WTFIG');
if isempty(WTFigH)
    WTFigH = figure('Name', 'Tracking Results', ...
        'NumberTitle', 'off', ...
        'Tag', 'WTFIG');
else
    figure(WTFigH);
end

%settings for movie output
axis tight;
set(gca,'nextplot','replacechildren');
set(gcf,'Renderer','zbuffer');


% Start Tracker
% -------------
for MN = 1, %for all movies
    
    %MovieObj = VideoReader();
    Tracks = [];
    
    % can use the information if necessary
    %NumberOfFrames = MovieObj.NumberOfFrames;
    
    
    %initiate video output
    %can use the following R2014b+ (see more comments on that below)
    outmovie = sprintf(strcat('tracked',int2str(start),'.mp4'));
    MovieOutObj = VideoWriter(outmovie, 'MPEG-4');
    MovieOutObj.FrameRate = framerate;
    open(MovieOutObj);

    %in R2015a, use avifile
    %hFig = figure('Visible','off');
    %set(hFig, 'PaperPositionMode','auto', 'InvertHardCopy','off')
    %aviobj = avifile('tracked.avi', 'fps', framerate);
    
    %   if circular clipping, precompute the clip area (use it as a multiplication mask)
%     if ~isempty(circularclip),
%         cx = round(circularclip(1));
%         cy = round(circularclip(2));
%         ra = round(circularclip(3));
        
        % MovieFrame = read(MovieObj, 1); %if read() is still supported (R2014a doensn't have readFrame yet)
        
%         SX = RES_H;
%         SY = RES_V;
%         
%         mask = ones(SY, SX, 1);
%         for xx = 1 : SX
%             for yy = 1 : SY
%                 if (xx - cx)^2 + (yy - cy)^2 > ra^2, %outside the circle
%                     mask(yy, xx, :) = 0;
%                 end
%             end
%         end
%         mask = uint8(mask);
%     end    
    
    % Analyze Movie
    % -------------
    firstframe = start;
    for frameno = firstframe : firstframe + NumberOfFrames,
        fprintf('Processing frame no %d\n', frameno);
        
        try
            %MovieFrame = read(MovieObj, frameno); %if read() is still supported (R2014a doensn't have readFrame yet)
            OriginalImage = imread(sprintf(strcat(image_name,'_%04d.bmp'), frameno));
            
%             %%%% KF addition to remove background
%             background = imopen(MovieFrame,strel('disk',10));
            whiteworm = 255 - OriginalImage;
%             imshow(whiteworm)
%             pause;
%             close

            I2 = whiteworm - background;
%             imshow(I2)
%             pause;
%             close
            
            MovieFrame = imadjust(I2,[0.1 0.25],[]);
%             imshow(MovieFrame)
%             pause;
%             close


        catch
           %hasFrame(MovieObj); %touch the frame pointer
           %MovieFrame = readFrame(MovieObj); %if read is no more supported, readFrame will (readFrame doesn't need the frameno argument; it just reads the next frameno; haven't tested though!)
        end
        
%         if ~isempty(rectangularclip),
%             MovieFrame = MovieFrame(rectangularclip(1) : rectangularclip(2), rectangularclip(3) : rectangularclip(4), :);
%         end
        
        %record the stimulus (LED at the very edge of the image)
%         stimval = double(MovieFrame(end, end, :));
        
%         if ~isempty(circularclip),
%             %apply the circular mask
%             MovieFrame = MovieFrame .* mask;
%             
%             %reduce the size
%             MovieFrame = MovieFrame(cy - ra : cy + ra, cx - ra : cx + ra, :);
%         end
%         [a, MSGID] = lastwarn();
%         warning('off', MSGID);
                
%         if frameno == firstframe,
%             figure;
%             imshow(MovieFrame);
% %               pause;
%         end
        
        % Convert frame to a binary image
        if WormTrackerPrefs.AutoThreshold       % use auto thresholding
            Level = graythresh(MovieFrame); %+ WormTrackerPrefs.CorrectFactor;
            Level = max(min(Level,1) ,0);
        else
            Level = WormTrackerPrefs.ManualSetLevel;
%             Level = graythresh(MovieFrame);
        end
        if WormTrackerPrefs.DarkObjects  %DarkObjects = 0 so not True
            BW = ~im2bw(MovieFrame, Level);  % For tracking dark objects on a bright background
        else
            BW = im2bw(MovieFrame, Level);  % For tracking bright objects on a dark background
        end

        %%%% KF addition to remove background noise
        BW = bwareaopen(BW, WormTrackerPrefs.MinWormArea);
%         imshow(BW)
%         pause;
%         close

        % Identify all objects
        [L,NUM] = bwlabel(BW);
        STATS = regionprops(L, {'Area', 'Centroid', 'FilledArea', 'Eccentricity'});
        
        % Identify all worms by size, get their centroid coordinates
        WormIndices = find([STATS.Area] > WormTrackerPrefs.MinWormArea & ...
            [STATS.Area] < WormTrackerPrefs.MaxWormArea);
        NumWorms = length(WormIndices);
        WormCentroids = [STATS(WormIndices).Centroid];
        WormCoordinates = [WormCentroids(1:2:2*NumWorms)', WormCentroids(2:2:2*NumWorms)'];
        WormSizes = [STATS(WormIndices).Area];
        WormFilledAreas = [STATS(WormIndices).FilledArea];
        WormEccentricities = [STATS(WormIndices).Eccentricity];
        
        % Track worms
        % -----------
        if ~isempty(Tracks)
            ActiveTracks = find([Tracks.Active]);
        else
            ActiveTracks = [];
        end
        
        % Update active tracks with new coordinates
        for i = 1:length(ActiveTracks)
%             Tracks(ActiveTracks(i)).Stimulus = [Tracks(ActiveTracks(i)).Stimulus; stimval]
            DistanceX = WormCoordinates(:,1) - Tracks(ActiveTracks(i)).LastCoordinates(1);
            DistanceY = WormCoordinates(:,2) - Tracks(ActiveTracks(i)).LastCoordinates(2);
            Distance = sqrt(DistanceX.^2 + DistanceY.^2);
            [MinVal, MinIndex] = min(Distance);
            if (MinVal <= WormTrackerPrefs.MaxDistance) & ...
                    (abs(WormSizes(MinIndex) - Tracks(ActiveTracks(i)).LastSize) < WormTrackerPrefs.SizeChangeThreshold)
                Tracks(ActiveTracks(i)).Path = [Tracks(ActiveTracks(i)).Path; WormCoordinates(MinIndex, :)];
                Tracks(ActiveTracks(i)).LastCoordinates = WormCoordinates(MinIndex, :);
                Tracks(ActiveTracks(i)).Frames = [Tracks(ActiveTracks(i)).Frames, frameno];
                Tracks(ActiveTracks(i)).Size = [Tracks(ActiveTracks(i)).Size, WormSizes(MinIndex)];
                Tracks(ActiveTracks(i)).LastSize = WormSizes(MinIndex);
                Tracks(ActiveTracks(i)).FilledArea = [Tracks(ActiveTracks(i)).FilledArea, WormFilledAreas(MinIndex)];
                Tracks(ActiveTracks(i)).Eccentricity = [Tracks(ActiveTracks(i)).Eccentricity, WormEccentricities(MinIndex)];
                WormCoordinates(MinIndex,:) = [];
                WormSizes(MinIndex) = [];
                WormFilledAreas(MinIndex) = [];
                WormEccentricities(MinIndex) = [];
            else
                Tracks(ActiveTracks(i)).Active = 0;
                if length(Tracks(ActiveTracks(i)).Frames) < WormTrackerPrefs.MinTrackLength
                    Tracks(ActiveTracks(i)) = [];
                    ActiveTracks = ActiveTracks - 1;
                end
            end
        end
        
        % Start new tracks for coordinates not assigned to existing tracks
        NumTracks = length(Tracks);
        for i = 1:length(WormCoordinates(:,1))
            Index = NumTracks + i;
            Tracks(Index).Active = 1;
            Tracks(Index).Path = WormCoordinates(i,:);
            Tracks(Index).LastCoordinates = WormCoordinates(i,:);
            Tracks(Index).Frames = frameno;
            Tracks(Index).Size = WormSizes(i);
            Tracks(Index).LastSize = WormSizes(i);
            Tracks(Index).FilledArea = WormFilledAreas(i);
            Tracks(Index).Eccentricity = WormEccentricities(i);
%             Tracks(Index).Stimulus = double(0.0);
        end
        
        % Display every FrameRate'th frame
        if ~mod(frameno, 4)
            if recordbw,
                mov.cdata = BW;
                mov.colormap = [];
            else
                mov.cdata = OriginalImage;
                mov.colormap = [];
            end                
            PlotFrame(WTFigH, mov, Tracks);
            FigureName = sprintf('Tracking Results for frame %d   ', frameno);
            set(WTFigH, 'Name', FigureName);
            
            %%% KF - put frame number on the figure for the video
            text(10,100,num2str(frameno),'Color','white','FontSize',14);
            
            if WormTrackerPrefs.PlotRGB
                RGB = label2rgb(L, @jet, 'k');
                figure(6)
                set(6, 'Name', FigureName);
                imshow(RGB);
                hold on
                if ~isempty(Tracks)
                    ActiveTracks = find([Tracks.Active]);
                else
                    ActiveTracks = [];
                end
                for i = 1:length(ActiveTracks)
                    plot(Tracks(ActiveTracks(i)).LastCoordinates(1), ...
                        Tracks(ActiveTracks(i)).LastCoordinates(2), 'wo');
                end
                hold off
            end
            
            if WormTrackerPrefs.PlotObjectSizeHistogram
                figure(7)
                hist([STATS.Area],300)
                set(7, 'Name', FigureName);
                title('Histogram of Object Sizes Identified by Tracker')
                xlabel('Object Size (pixels')
                ylabel('Number of Occurrences')
            end
            
            if WormTrackerPrefs.PauseDuringPlot
                pause;
            end
            
            %write frame to video
            %frame = getframe(gcf); %getframe sucks, capture anything
            %that's on the screen
            
            %the following is an alternative to getframe, but only works in
            %R2014b+; But R2015b has issue with exporting eps (exports triangular objects) so not using it;
            %try to see whether R2015 fixes that; in that case, can use the
            %following code:
           framepar.resolution = [RES_H, RES_V];
           [frame] = fig2frame(gcf, framepar);
           writeVideo(MovieOutObj,frame);

%so for now, use the deprecated avifile (may slow things down)
  %          aviobj = addframe(aviobj, frame);
        end
        
    end    % END for frameno = 1:MovieObj.NumFrames
    
    %save the video
    %use in R2014b+
   close(MovieOutObj);
    %for the moment (R2014a), use:
   %    aviobj = close(aviobj);
    
    % Get rid of invalid tracks
    DeleteTracks = [];
    for i = 1:length(Tracks)
        if length(Tracks(i).Frames) < WormTrackerPrefs.MinTrackLength
            DeleteTracks = [DeleteTracks, i];
        end
    end
    Tracks(DeleteTracks) = [];
    
    % Save Tracks
    SaveFileName = sprintf(strcat('wormcords',int2str(start),'.mat'));
    save(SaveFileName, 'Tracks');
    
    close all; %close fig
end