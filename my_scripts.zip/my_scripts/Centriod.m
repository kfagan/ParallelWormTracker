

% bg = im2bw(imread('background.bmp'));
pic = imread('WhiteWorm_image_0001.bmp');
%worm = rgb2gray(pic);
level = graythresh(pic)
%BW = im2bw(worm,level);


%BW = im2bw(pic,level);
%imshow(BW)
BW = im2bw(pic, .45);
imshow(BW)
pause;

BW = bwareaopen(BW, 350);
imshow(BW)
pause;

% BW = BW.*bg;
% imshow(BW)
% pause;
% Identify all objects


[L,num] = bwlabel(BW);
%Calculate centroids for connected components in the image using regionprops.

STATS = regionprops(L,{'Area','Centroid','FilledArea'});
%Concatenate structure array containing centroids into a single matrix.

WormIndices = find([STATS.Area] > 350 & ...
            [STATS.Area] < 1400);
NumWorms = length(WormIndices);
WormCentroids = [STATS(WormIndices).Centroid];
WormFilledAreas = [STATS(WormIndices).FilledArea];
WormCoordinates = [WormCentroids(1:2:2*NumWorms)', WormCentroids(2:2:2*NumWorms)'];


centroids = cat(1, WormCoordinates);
%Display binary image with centroid locations superimposed.


imshow(BW)
hold on
plot(centroids(:,1),centroids(:,2), 'b*')
hold off

WormFilledAreas

pause;
close all;
 
