

load 'wormcords1-4000_FIXED.mat'
t1 = Tracks;

load 'wormcords4001-6231_FIXED.mat'
t2 = Tracks;

load 'wormcords6232_FIXED.mat'
t3 = Tracks;

load 'wormcords8002_FIXED.mat'
t4 = Tracks;
% 
% load 'wormcords12001-14401_FIXED.mat'
% t5 = Tracks;

Tracks.Active = 1;
Tracks.Path = vertcat(t1.Path(:,:), t2.Path(:,:), t3.Path(:,:), t4.Path(:,:));
Tracks.LastCoordinates = t4.LastCoordinates ;
Tracks.Frames = [t1.Frames t2.Frames t3.Frames t4.Frames];
Tracks.Size = [t1.Size t2.Size t3.Size t4.Size];
Tracks.LastSize = t4.LastSize;
Tracks.FilledArea = [t1.FilledArea t2.FilledArea t3.FilledArea t4.FilledArea];
Tracks.Eccentricity = [t1.Eccentricity t2.Eccentricity t3.Eccentricity t4.Eccentricity];

SaveFileName = sprintf(strcat('wormcords_FIXED.mat'));
    save(SaveFileName, 'Tracks');