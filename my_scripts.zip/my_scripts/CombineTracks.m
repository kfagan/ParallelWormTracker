

% path1 = 'F:\WormTracking\basler\jan6_2016\vid2\info\analyzedcords.mat';
% path2 = 'F:\WormTracking\basler\jan7_2016\vid3\info\analyzedcords.mat';
% path3 = 'F:\WormTracking\basler\jan11_2016\him-5_herm\ctrl\analyzedcords.mat';
% herm1 = 'F:\WormTracking\basler\jan20_2016\herm\analyzedcords.mat';
% herm2 = 'F:\WormTracking\basler\jan22_2016\herm\analyzedcords.mat';
% herm3 = 'F:\WormTracking\basler\jan22_2016\herm2\analyzedcords.mat';
% herm4 = 'F:\WormTracking\basler\jan22_2016\herm3\analyzedcords.mat';
% 
% male101 = 'F:\WormTracking\basler\jan20_2016\male\10s_analyzedTotalWormcords.mat';
% male102 = 'F:\WormTracking\basler\jan26_2016\male1\10s_analyzedcords.mat';
% male103 = 'F:\WormTracking\basler\jan26_2016\male2\10s_analyzedcords.mat';
% 
% male51 = 'F:\WormTracking\basler\jan20_2016\male\5s_analyzedTotalWormcords.mat';
% male52 = 'F:\WormTracking\basler\jan26_2016\male1\5s_analyzedcords.mat';
% male53 = 'F:\WormTracking\basler\jan26_2016\male2\5s_analyzedcords.mat';

% path1 = 'F:\WormTracking\basler\jan6_2016\vid2\info\analyzedcords.mat';
% path2 = 'F:\WormTracking\basler\jan7_2016\vid3\info\analyzedcords.mat';
% path3 = 'F:\WormTracking\basler\jan11_2016\him-5_herm\ctrl\analyzedcords.mat';




function AllTracks = CombineTracks(varargin)
%%% Combines multiple tracks
    AllTracks = [];
    for i = 1:nargin
        paths = char(varargin(i));
        load(paths)
        AllTracks = [AllTracks, Tracks];
    end
    Tracks = AllTracks;
save('him-5_male_wormcords.mat', 'Tracks');
end


    