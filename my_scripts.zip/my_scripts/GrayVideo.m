





for frameno = 1:1000;
    [OriginalImage, map] = imread(sprintf('acA3800-14um__21683910__20160210_165945542_%04d.bmp', frameno));
    small = imresize(OriginalImage,0.1);
    F(frameno) = im2frame(small,map);
end
movie(F)