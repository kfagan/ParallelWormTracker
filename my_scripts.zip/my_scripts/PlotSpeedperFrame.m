% 
% angular = [];
% linear = [];
% frame = [];
% for i = 1:length(Tracks)
%     angular = [angular Tracks(i).AvgAng];
%     linear = [linear Tracks(i).AvgLin];
%     frame = [frame Tracks(i).AvgFrame];
% 
% %         angular = [angular round(abs(Tracks(i).AngSpeed))];
% %         linear = [linear round(Tracks(i).Speed)];
% end
% 
% plot(frame, linear)
% pause;
% close;
% plot(frame, angular)
% pause;
% close;

figure
for i = 1:length(Tracks)
    % Angular Speed
    subplot(2,1,1)
    plot(Tracks(i).AvgFrame,Tracks(i).AvgAng)
    axis([0 inf 0 80])
    ylabel('angular speed (deg/s)') % x-axis label
    
    % Linear Speed
    subplot(2,1,2)
    plot(Tracks(i).AvgFrame, Tracks(i).AvgLin)
    axis([0 inf 0 .3])
    ylabel('speed (mm/s)') % y-axis label
    xlabel('time (s)') % y-axis label
    
    i
    
pause;
close
end

pause;
close;