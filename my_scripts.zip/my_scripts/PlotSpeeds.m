


%%% Plot Angular and Linear speeds of each worm track


for i = 1:length(Tracks)
    figure(2)
    % Angular Speed
    subplot(2,1,1)
    plot(Tracks(i).AngSpeed)
    axis([0 910 -200 200])
    ylabel('angular speed (deg/s)') % x-axis label
    
    % Linear Speed
    subplot(2,1,2)
    plot(Tracks(i).Speed)
    axis([0 910 0 .5])
    ylabel('speed (mm/s)') % y-axis label
    xlabel('frames') % y-axis label

pause;
close
end

    





