
function PlotSpeedsScatter(Tracks)
    
    %%% Combine all the averaged angular speeds into one vector while preserving order.
    %%% Do the same with the average linear speeds.
    
    angular = [];
    linear = [];
    for i = 1:length(Tracks)
        angular = [angular Tracks(i).AvgAng];
        linear = [linear Tracks(i).AvgLin];
        
%         angular = [angular abs(Tracks(i).AngSpeed)];
%         linear = [linear Tracks(i).Speed];
    end
    
    
    %%%%%Count the number of times each linear/angular pair occurs
    
%     [bA, mA, nA] = unique(angular);
%     [bB, mB, nB] = unique(linear);
%     aa = accumarray([nA(:), nB(:)],1);
% 
%     [ii jj vv] = find(aa);
%     counts = [ii jj vv];
% 
%     %%% Extract counts in the form of:
%     %   x = averaged angular speed
%     %   y = average linear speed 
%     %   z = count number for that pair
%     
%     x = bA(counts(:,1));
%     y = bB(counts(:,2));
%     z = reshape(counts(:,3),[1, length(counts(:,3))]);
%     
%     
%     
%     %%% Make scatter plot
%     pointsize = 15;
%     scatter(x, y, pointsize, z, 'filled')
% %     gscatter(x, y, z/sum(z))
% %     axis([0 180 0 .45])
%     xlabel('angular speed (deg/s)') % x-axis label
%     ylabel('speed (mm/s)') % y-axis label
%     hold on
%     plot(x, x/450)
% 	pause;
% 	close
	
    
% %     clusterdata = kmeans([angular(:),linear(:)],2);
%     %Run k-means for a range of k
% X = [angular(:),linear(:)];
% opts = statset('Display','final');
% [idx,C] = kmeans(X,2,'Distance','cosine','Replicates',20,'Options',opts);
% 
% 
% figure;
% plot(X(idx==1,1),X(idx==1,2),'r.','MarkerSize',12)
% hold on
% plot(X(idx==2,1),X(idx==2,2),'b.','MarkerSize',12)
% plot(C(:,1),C(:,2),'kx',...
%      'MarkerSize',15,'LineWidth',3)
% legend('Cluster 1','Cluster 2','Centroids',...
%        'Location','NW')
% title 'Cluster Assignments and Centroids'
% hold off
% 
% pause
% close
    
    scatter(angular(:),linear(:))
    xlabel('angular speed (deg/s)') % x-axis label
    ylabel('speed (mm/s)') % y-axis label
    axis([0 180 0 .45])
    pause;
    close
%     
%     scatter(angular(:),linear(:), pointsize, clusterdata, 'filled')
%     xlabel('angular speed (deg/s)') % x-axis label
%     ylabel('speed (mm/s)') % y-axis label
%     pause;
%     close
    
    centers = {(0:0.01:0.4),(0:2:180)};
    hist3([linear(:),angular(:)], 'Ctrs', centers)
    pause;
    close
    
    
    xticks = linspace(0,180,91);
    yticks = linspace(0,.4, 40);


    mat = [linear(:) angular(:)];
    ndims(mat)
    numel(mat)
    size(mat)
    
    colormap('hot')
%     'XTickLabel', [20, 40, 60, 80, 100, 120, 140, 160, 180],
    imagesc(hist3([linear(:),angular(:)], 'Ctrs', centers))
    set(gca,'YTickLabel',[0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4],'XTickLabel', [20, 40, 60, 80, 100, 120, 140, 160, 180],'YDir','normal')
    colorbar()
    xlabel('angular speed (deg/s)') % x-axis label
    ylabel('speed (mm/s)') % y-axis label

    pause;
    close
    
    
    imagesc(hist3([DH_distances(:) DH_linear(:)],[200 40]))
    
%     centers = {(0:10:80),(0:0.005:0.3)};
%     imagesc(hist3([angular(:),linear(:)], 'Ctrs', centers))
%     n = imagesc(hist3([linear(:),angular(:)],[100 1]));
% 	n1 = n';
%     n1(size(n,1) + 1, size(n,2) + 1) = 0;

		
	
end