function RenameImages()

%%% Images taken from the basler ace camera have long obnoxious names that
%%% I don't know how to change in Pylon. So I wrote this script to
%%% convert the file names into "image_0001.bmp" format.

%%% How to use: navagate to the folder containing the images. Type
%%% command RenameImages and all the files in the folder will be renamed.

imagefiles = dir('*.bmp');
bas = imagefiles(1).name;
basler = strsplit(bas,'0001.bmp');
basler = char(basler(1));

for i = 1:length(imagefiles)
    movefile(sprintf(strcat(basler,'%04d.bmp'),i),sprintf('image_%04d.bmp',i));
end
end
