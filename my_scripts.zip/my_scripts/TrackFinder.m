
for i =1:length(Tracks)
plot(Tracks(i).Path(:,1),-Tracks(i).Path(:,2))
hold on
text(Tracks(i).Path(1,1), -Tracks(i).Path(1,2),num2str(i),'FontSize',14);
end
hold off