function WhiteWorm(filetype)
%%% WormTracker works better when worms are white and the background is
%%% black. This function converts a black worm/white background image a to
%%% white worm/black background image.

%%% To use, navigate to the directory containing images that need adjusting
%%% and type the command WhiteWorm. This will create a new folder called
%%% "WhiteWorms" containing the new white worm/black background images.

imagefiles = dir(strcat('*.',filetype));
% Get list of all files of a specificied type in this directory
% DIR returns as a structure array.  You will need to use () and . to get
% the file names.
     
nfiles = length(imagefiles);    % Number of files found
currentdir = pwd;   %get current directory
mkdir('WhiteWorm')

for ii=1:nfiles
   currentfilename = imagefiles(ii).name;
   currentimage = imread(currentfilename);
   imwrite(255-currentimage,strcat(currentdir,'\WhiteWorm\WhiteWorm_',imagefiles(ii).name));
end

end
