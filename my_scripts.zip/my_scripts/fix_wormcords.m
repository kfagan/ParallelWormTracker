function fix_wormcords(wormcord, TrackNum, last)

load(wormcord)

T = Tracks(TrackNum);
Tracks = struct();
if last == 1
    finish = 2401;
else
    finish = 4000;
end

Tracks.Active = 1;
Tracks.Path = T.Path(1:finish,:);
Tracks.LastCoordinates = T.LastCoordinates;
Tracks.Frames = T.Frames(1:finish);
Tracks.Size = T.Size(1:finish);
Tracks.LastSize = T.LastSize;
Tracks.FilledArea = T.FilledArea(1:finish);
Tracks.Eccentricity = T.Eccentricity(1:finish);


NewName = strcat(wormcord(1:end-4), '_FIXED.mat');
SaveFileName = NewName;
    save(SaveFileName, 'Tracks');