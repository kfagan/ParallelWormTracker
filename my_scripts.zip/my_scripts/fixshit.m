
load wormcords4001_original.mat
t1 = Tracks(2);
t3 = Tracks(12);
t5 = Tracks(13);
t7 = Tracks(15);
t9 = Tracks(17);
t11 = Tracks(18);

t4 = struct(); %5298 5299 5300
t4diff = (t5.Path(1,:) - t3.Path(end,:))/4;
t4.Path = vertcat(t3.Path(end,:)+t4diff, t3.Path(end,:)+2*t4diff, t3.Path(end,:)+3*t4diff);
t4.Frames = [5298 5299 5300];
t4ecc = (t5.Eccentricity(1) - t3.Eccentricity(end))/4;
t4.Eccentricity = [t3.Eccentricity(end)+t4ecc, t3.Eccentricity(end)+2*t4ecc, t3.Eccentricity(end)+3*t4ecc];
t4.Size = repmat(t3.Size(end),1,3);
t4.FilledArea = repmat(t3.FilledArea(end),1,3);

t6 = struct();  %5865
t6diff = (t7.Path(1,:) - t5.Path(end,:))/2;
t6.Path = vertcat(t5.Path(end,:)+t6diff);
t6.Frames = 5865;
t6ecc = (t7.Eccentricity(1) - t5.Eccentricity(end))/2;
t6.Eccentricity = t5.Eccentricity(end)+t6ecc;
t6.Size = t5.Size(end);
t6.FilledArea = t5.FilledArea(end);

t8 = struct();  %5969 5970 5971
t8diff = (t9.Path(1,:) - t7.Path(end,:))/4;
t8.Path = vertcat(t7.Path(end,:)+t8diff, t7.Path(end,:)+2*t8diff, t7.Path(end,:)+3*t8diff);
t8.Frames = [5969 5970 5971];
t8ecc = (t9.Eccentricity(1) - t7.Eccentricity(end))/4;
t8.Eccentricity = [t7.Eccentricity(end)+t8ecc, t7.Eccentricity(end)+2*t8ecc, t7.Eccentricity(end)+3*t8ecc];
t8.Size = repmat(t7.Size(end),1,3);
t8.FilledArea = repmat(t7.FilledArea(end),1,3);


t10 = struct(); %6060 
t10diff = (t11.Path(1,:) - t9.Path(end,:))/2;
t10.Path = t9.Path(end,:)+t10diff;
t10.Frames = 6060;
t10ecc = (t11.Eccentricity(1) - t9.Eccentricity(end))/2;
t10.Eccentricity = t9.Eccentricity(end)+t10ecc;
t10.Size = t9.Size(end);
t10.FilledArea = t9.FilledArea(end);

load wormcords4994.mat
t2 = Tracks(4);

% load wormcords2108.mat
% t3 = Tracks(1);
% t5 = Tracks(2);
% 
% load wormcords2168.mat
% t4 = Tracks(2);

Tracks = struct();
Tracks.Active = 1;
Tracks.Path = vertcat(t1.Path(:,:), t2.Path(:,:), t3.Path(:,:), t4.Path(:,:), t5.Path(:,:), t6.Path(:,:), t7.Path(:,:), t8.Path(:,:), t9.Path(:,:), t10.Path(:,:), t11.Path(:,:));
Tracks.LastCoordinates = t11.LastCoordinates;
Tracks.Frames = [t1.Frames t2.Frames t3.Frames t4.Frames t5.Frames t6.Frames t7.Frames t8.Frames t9.Frames t10.Frames t11.Frames];
Tracks.Size = [t1.Size t2.Size t3.Size t4.Size t5.Size t6.Size t7.Size t8.Size t9.Size t10.Size t11.Size];
Tracks.LastSize = t11.LastSize;
Tracks.FilledArea = [t1.FilledArea t2.FilledArea t3.FilledArea t4.FilledArea t5.FilledArea t6.FilledArea t7.FilledArea t8.FilledArea t9.FilledArea t10.FilledArea t11.FilledArea];
Tracks.Eccentricity = [t1.Eccentricity t2.Eccentricity t3.Eccentricity t4.Eccentricity t5.Eccentricity t6.Eccentricity t7.Eccentricity t8.Eccentricity t9.Eccentricity t10.Eccentricity t11.Eccentricity];


NewName = strcat('wormcords4001-8001_FIXED.mat');
SaveFileName = NewName;
    save(SaveFileName, 'Tracks');