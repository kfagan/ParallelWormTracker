fixed  = imread('acA3800-14um__21683910__20160112_121746692_0001.bmp');
moving = imread('acA3800-14um__21683910__20160112_121746692_2069.bmp');
% View the misaligned images.

imshowpair(fixed, moving,'Scaling','joint');
pause;
close;
% 
% [optimizer, metric] = imregconfig('monomodal');
% % 
% % optimizer.InitialRadius = 0.009;
% % optimizer.Epsilon = 1.5e-4;
% % optimizer.GrowthFactor = 1.01;
% % optimizer.MaximumIterations = 300;
% 
% movingRegistered = imregister(moving, fixed, 'translation', optimizer, metric);
% 
% figure
% imshowpair(fixed, movingRegistered,'Scaling','joint');
