
    %%%% average linear and angular speeds over 10s intervals
        linear = [1,2,3,4,5,6,7,8,9,10,3,3,3,3,3,10,11,12,11,10,0,0,0];
        length(linear)
        a = [];
        b = [];
        expected = [];
        for t = 0:5:length(linear)-5
        t
%         q = linear(1+t:5+t)
%         mean(q)
            a = [a round(mean(linear(1+t:5+t))*1000)/1000];
            b = [b round(mean(linear(1+t:5+t)))];
        end
a
b

