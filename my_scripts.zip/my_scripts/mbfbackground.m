function mbfbackground(image_name)
%%% WormTracker works better when worms are white and the background is
%%% black. This function converts a black worm/white background image a to
%%% white worm/black background image.

%%% To use, navigate to the directory containing images that need adjusting
%%% and type the command WhiteWorm. This will create a new folder called
%%% "WhiteWorms" containing the new white worm/black background images.

% imagefiles = dir('*.bmp'); 
% % Get list of all BMP files in this directory
% % DIR returns as a structure array.  You will need to use () and . to get
% % the file names.
%      
% nfiles = length(imagefiles);    % Number of files found
currentdir = pwd;   %get current directory
mkdir('MBF')

bgImage = 255 - imread(strcat(image_name,'_0001.bmp'));
background = imopen(bgImage,strel('disk',7));

for i = 1:3
    currentimage = sprintf(strcat(image_name,'_%04d.bmp'),i);
    I = 255 - imread(currentimage);
    I2 = I - background;
    imshow(I2)
    pause;
    close
    
    new_name = strcat(currentdir,'\MBF\',sprintf('image_%04d.tiff',i));
    
    imwrite(I2,new_name);
end

% for ii=1:nfiles
%    currentfilename = imagefiles(ii).name;
%    currentimage = imread(currentfilename);
%    imwrite(255-currentimage,strcat(currentdir,'\WhiteWorm\WhiteWorm_',imagefiles(ii).name));
% end
% 
% end
