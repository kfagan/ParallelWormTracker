% Get rid of background - from:
% http://www.mathworks.com/help/images/image-enhancement-and-analysis.html

function mbftiffs()

    imagefiles = dir('*.bmp');
    nfiles = length(imagefiles);    % Number of files found
    currentdir = pwd;   %get current directory
    mkdir('MBF')

    bg = imread(imagefiles(1).name);
    background = imopen(bg,strel('disk',10));

    for i=1:nfiles
        currentfilename = imagefiles(i).name;
        I = imread(currentfilename);
        I2 = I - background;
        I3 = imadjust(I2,[0.1 .4],[]);

        level = graythresh(I3)
        bw = im2bw(I3,level);
        bw2 = bwareaopen(bw, 100);
      
        
        newname = strcat(imagefiles(i).name(11:20),'.tiff');
        imwrite(I2,strcat(currentdir,'\MBF\',newname));
    end

end