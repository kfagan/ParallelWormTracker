


%%% Are the tracks actual worm tracks? Plot them all the same graph and
%%% compare with the tracked video.


figure

for i = 1:length(Tracks)
    subplot(2,1,1)
    plot(s(i).Lin)
    axis([0 3600 0 inf])
    
    subplot(2,1,2)
    plot(s(i).Ang)
    axis([0 3600 -50 50])
    
pause;
close

end

% figure
% 
% for i = 1:length(Tracks)
%     subplot(2,1,1)
%     plot(Tracks(i).Path(:,1),Tracks(i).Path(:,2))
%     
%     
%     subplot(2,1,2)
%     plot(Tracks(i).SmoothX,Tracks(i).SmoothY)
%     
%     
% pause;
% close
% 
% end

    
% 
% figure
% 
% for i = 1:length(Tracks)
%     xax = 1:length(Velocity(i).Linear);
%     plot(xax,Velocity(i).Linear, xax,Vel(i).Angular)
%     pause;
%     close;
% end
% 





