

%%%% average linear and angular speeds over 10s intervals


Speed = struct;
xang = [];
xlin = [];
s = struct;

for i = 1:length(Tracks)    % loop through all your worms
        count = 1;
        linear = [];
        angular = [];
        
        for t = 0:10:length(Tracks(i).Speed)-10
            linear(count) = round(mean(Tracks(i).Speed(1+t:10+t))*1000)/1000;
            angular(count) = abs(round(mean(Tracks(i).AngSpeed(1+t:10+t))));
            count = count + 1;    
        end
        Tracks(i).AvgLin = linear;
        Tracks(i).AvgAng = angular;
end

