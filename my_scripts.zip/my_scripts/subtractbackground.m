% Get rid of background - from:
% http://www.mathworks.com/help/images/image-enhancement-and-analysis.html
% 
background = imread('background.bmp');
background = 255-background;
% % I = imadjust(I,[.1,.6],[]);
% % imshow(I)
% % pause;
% % close
% 
% background = imopen(background,strel('disk',2));
% imshow(background);
% pause;
% close

% figure
% surf(double(background(1:8:end,1:8:end))),zlim([0 255]);
% set(gca,'ydir','reverse');
test = imread('acA3800-14um__21683910__20160803_121648785_0230.bmp');
test = 255-test;
% test = imadjust(test,[.1,.5],[]);
% imshow(test)
% pause;
% close


% test = imhistmatch(test,I);

% test = movingRegistered;
% 
% imshow(test)
% pause;
% close

% I2 = test - I;
% I2 = test - background;
% imshow(I2)
% pause;
% close

I2 = test;
I3 = test-background;
% imshow(I3)
% pause;
% close

bm = imread('background_multiply.bmp');
b = uint8(im2bw(bm,.5));

I3 = I3.*b;
h = fspecial('gaussian',5,4);
I3 = imgaussfilt(I3,1);
I3 = imadjust(I3,[.1,.15],[]);
% imshow(I3)
% pause
% close


%Use gaussian filter to try to smooth worm shape before converting to
%binary
% h = fspecial('gaussian',5,4);
% I3 = imfilter(I3,h);
% imshow(I3)
% pause;
% close


level = graythresh(I2)

level = graythresh(I3)


imbw1 = im2bw(I2,.5);
imbw2 = im2bw(I3,.5);

se = strel('disk',5);
closeBW = imclose(I3,se);
imbw3 = im2bw(closeBW,.5);
% imshow(imbw3)
% pause;
% close

% subplot(1,3,1);
% imshow(closeBW);
% subplot(1,3,2);
% imshow(imbw3);
% subplot(1,3,3);
% imshow(imbw2)

% 
% abw1 = bwareaopen(imbw1, 200);
% abw2 = bwareaopen(imbw2, 200);
% 
% 
subplot(2,2,1);
imshow(I3);
subplot(2,2,2);
imshow(imbw2);
subplot(2,2,3);
imshow(closeBW);
subplot(2,2,4);
imshow(imbw3);

% 
% 
% % Add circular mask
% % focuspar = [220, -40, 7];
% % center_x = RES_H / 2 - focuspar(1);
% % center_y = RES_V / 2 - focuspar(2);
% % radius = RES_V / focuspar(3);
% % circularclip = [center_x, center_y, radius]; %center_x, center_y, radius
% 
% 
% 
% [L,num] = bwlabel(bw2);
% %Calculate centroids for connected components in the image using regionprops.
% 
% STATS = regionprops(L,{'Area','Centroid','FilledArea'});
% %Concatenate structure array containing centroids into a single matrix.
% 
% WormIndices = find([STATS.Area] > 50 & ...
%             [STATS.Area] < 200);
% NumWorms = length(WormIndices);
% WormCentroids = [STATS(WormIndices).Centroid];
% WormFilledAreas = [STATS(WormIndices).FilledArea];
% WormCoordinates = [WormCentroids(1:2:2*NumWorms)', WormCentroids(2:2:2*NumWorms)'];
% 
% 
% centroids = cat(1, WormCoordinates);
% %Display binary image with centroid locations superimposed.
% 
% 
% imshow(bw2)
% hold on
% plot(centroids(:,1),centroids(:,2), 'b*')
% hold off
% 