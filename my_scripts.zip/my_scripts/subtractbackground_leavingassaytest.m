% Get rid of background - from:
% http://www.mathworks.com/help/images/image-enhancement-and-analysis.html

I = imread('leavingassaytest6.bmp');
I = 255-I;
% imshow(I)
% pause;
% close

background = imopen(I,strel('square',5));
% figure
% surf(double(background(1:8:end,1:8:end))),zlim([0 255]);
% set(gca,'ydir','reverse');
test = imread('leavingassaytest6.1.bmp');
test = 255-test;
imshow(test)
pause;
close

I2 = test - I;
imshow(I2)
pause;
close;
% 
% hmmlevel = graythresh(hmm)
% hmmbw = im2bw(hmm,hmmlevel);
% imshow(testbw)
% pause;
% close



% test = imhistmatch(test,I);

% test = movingRegistered;
% 
% imshow(test)
% pause;
% close

% I2 = test - background;
% imshow(I2)
% pause;
% close

I3 = imadjust(I2,[.1,.2],[]);
imshow(I3)
pause;
close

level = graythresh(I3);
bw = im2bw(I3,.4);
imshow(bw)
pause;
close

bw2 = bwareaopen(bw, 10);
imshow(bw2)
pause;
close


% Add circular mask
% focuspar = [220, -40, 7];
% center_x = RES_H / 2 - focuspar(1);
% center_y = RES_V / 2 - focuspar(2);
% radius = RES_V / focuspar(3);
% circularclip = [center_x, center_y, radius]; %center_x, center_y, radius



% [L,num] = bwlabel(bw);
% %Calculate centroids for connected components in the image using regionprops.
% 
% STATS = regionprops(L,{'Area','Centroid','FilledArea'});
% %Concatenate structure array containing centroids into a single matrix.
% 
% WormIndices = find([STATS.Area] > 50 & ...
%             [STATS.Area] < 200);
% NumWorms = length(WormIndices);
% WormCentroids = [STATS(WormIndices).Centroid];
% WormFilledAreas = [STATS(WormIndices).FilledArea];
% WormCoordinates = [WormCentroids(1:2:2*NumWorms)', WormCentroids(2:2:2*NumWorms)'];
% 
% 
% centroids = cat(1, WormCoordinates);
% %Display binary image with centroid locations superimposed.
% 
% 
% imshow(bw)
% hold on
% plot(centroids(:,1),centroids(:,2), 'b*')
% hold off
% % 