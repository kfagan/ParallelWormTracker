
    %%%% average linear and angular speeds over 10s intervals
        linear = [1,2,3,4,5,6,7,8,9,10,3,3,3,3,3,10,11,12,11,10];
        length(linear)
        a = [];
        b = [];
        expected = [];
%         for t = 0:10:length(linear)-10
%         t
%             a = [a round(mean(linear(1+t:10+t))*1000)/1000];
%             b = [b round(mean(linear(1+t:10+t)))];
%         end
a
b

